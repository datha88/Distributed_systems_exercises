package de.unistgt.ipvs.vs.ex1.calcRMIserver;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import de.unistgt.ipvs.vs.ex1.calculation.ICalculationFactory;
import de.unistgt.ipvs.vs.ex1.calculationImpl.CalculationImplFactory;

/**
 * Implement the run-method of this class to complete
 * the assignment. You may also add some fields or methods.
 */
public class CalcRmiServer extends Thread{
	private String regHost;
	private String objName;
	
	public CalcRmiServer(String regHost, String objName) {
		this.regHost = regHost;
		this.objName = objName;
	}
	
	public CalcRmiServer() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		if (regHost == null || objName == null) {
			System.err.println("<registryHost> and/or <objectName> not set!");
			return;
		}
		
		try {
			ICalculationFactory iCalcFact = (ICalculationFactory) new CalculationImplFactory();
			//Registry registry = LocateRegistry.createRegistry(2020);
			Registry registry = LocateRegistry.getRegistry("localhost");
			System.out.println("Test");
			registry.rebind("sessionFactory", iCalcFact);
			System.out.println("Server is online");
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
