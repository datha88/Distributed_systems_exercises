package de.unistgt.ipvs.vs.ex1.calcRMIclient;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Collection;

import de.unistgt.ipvs.vs.ex1.calculation.ICalculation;
import de.unistgt.ipvs.vs.ex1.calculation.ICalculationFactory;

/**
 * Implement the getCalcRes-, init-, and calculate-method of this class as
 * necessary to complete the assignment. You may also add some fields or methods.
 */
public class CalcRmiClient {
	private ICalculation icalc = null;

	public CalcRmiClient() {
		this.icalc = null;
	}

	public int getCalcRes() {
		int res = 0;
		try {
			res = icalc.getResult();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

	public boolean init(String url){
		try {
			ICalculationFactory calculationFactory = (ICalculationFactory) Naming.lookup(url);
			icalc = calculationFactory.getSession();	
		} catch (RemoteException e) {
			e.printStackTrace();
			return false;
		}
		catch (MalformedURLException e) {
			e.printStackTrace();
			return false;
		}
		catch (NotBoundException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean calculate(CalculationMode calcMode, Collection<Integer> numbers) {
		// TODO
		if(numbers == null) {
			return false;
		}
		switch(calcMode)
		{
		case ADD:
			for (Integer val: numbers) {
				try {
					icalc.add(val);
					System.out.println(icalc.getResult());
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			break;
		case SUB:
			for (Integer val: numbers) {
				try {
					icalc.subtract(val);
					System.out.println(icalc.getResult());
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			break;
		case MUL:
			for (Integer val: numbers) {
				try {
					icalc.multiply(val);
					System.out.println(icalc.getResult());
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			break;
		}

		return true;
	}
}
