package de.uni_stuttgart.ipvs.ids.communication;

import java.io.Serializable;

public class ReleaseWriteLock implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3315386831872060741L;

}
