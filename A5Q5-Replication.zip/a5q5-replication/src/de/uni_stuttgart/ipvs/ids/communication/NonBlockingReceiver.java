package de.unistgt.ipvs.vs.ex5.communication;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

/**
 * Part b) Extend the method receiveMessages to return all DatagramPackets that
 * were received during the given timeout.
 * 
 * Also implement unpack() to conveniently convert a Collection of
 * DatagramPackets containing ValueResponseMessages to a collection of
 * VersionedValueWithSource objects.
 */
public class NonBlockingReceiver {
	protected DatagramSocket socket;

	private final int MAX_BUF_LENGTH = 65507;

	public NonBlockingReceiver(DatagramSocket socket) {
		this.socket = socket;
	}

	public Vector<DatagramPacket> receiveMessages(int timeoutMillis,
			int expectedMessages) throws IOException {
		this.socket.setSoTimeout(timeoutMillis);

		Vector<DatagramPacket> recpackets = new Vector<DatagramPacket>();
		int count = expectedMessages;
		try {
			while (count != 0) {

				DatagramPacket recPacket = new DatagramPacket(
						new byte[this.MAX_BUF_LENGTH], this.MAX_BUF_LENGTH);

				this.socket.receive(recPacket);
				recpackets.add(recPacket);
				count--;

			}
		} catch (SocketTimeoutException ex) {
			
			System.err.println("This is error due to socket timeout");
		}
		return recpackets;
	}

	public static <T> Collection<MessageWithSource<T>> unpack(
			Collection<DatagramPacket> packetCollection) throws IOException,
			ClassNotFoundException {
		Iterator<DatagramPacket> iter = packetCollection.iterator();
		Collection<MessageWithSource<T>> unPacked = new ArrayList<MessageWithSource<T>>();
		while (iter.hasNext()) {
			DatagramPacket pkt = iter.next();
			@SuppressWarnings("unchecked")
			MessageWithSource<T> msgSrc = new MessageWithSource<T>(
					pkt.getSocketAddress(),
					(T) NonBlockingReceiver.getObjectFromMessage(pkt));
			unPacked.add(msgSrc);
		}
		return unPacked;
	}

	/**
	 * Fetching Message from Object
	 * 
	 * @param packet
	 * @return
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	protected static Object getObjectFromMessage(DatagramPacket packet)
			throws IOException, ClassNotFoundException {

		ObjectInputStream objStream = new ObjectInputStream(
				new ByteArrayInputStream(packet.getData()));
		Object obj = objStream.readObject();

		return obj;
	}
}
