package de.unistgt.ipvs.vs.ex1.calcSocketClient;

import java.util.Scanner;

public class CalcClient {

	public static void main(String[] args) {
		System.out.println("Starting client");
		CalcSocketClient client = new CalcSocketClient();
		if(client.connectTo(args[0], Integer.parseInt(args[1]))) {
			CalcClient calcClient = new CalcClient();
			calcClient.serve(client);
		} else {
			System.err.println("Connection failed. Exiting.");
			System.exit(-1);
		}
	}
	
	private void serve(CalcSocketClient client) {
		String input = null;
		Scanner in = new Scanner(System.in);
		do {
			// Read input
			System.out.println("Enter message or type exit to quit:");
			input = in.nextLine();
			input = input != null ? input.trim() : null;
			client.calculate(input);
		} while(!"exit".equalsIgnoreCase(input));
		
		System.out.println("Exiting.. Bye Bye..");
		in.close();
		client.disconnect();
	}

}
