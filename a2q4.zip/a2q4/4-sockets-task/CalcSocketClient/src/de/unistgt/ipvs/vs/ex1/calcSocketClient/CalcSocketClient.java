package de.unistgt.ipvs.vs.ex1.calcSocketClient;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Implement the connectTo-, disconnect-, and calculate-method of this class as
 * necessary to complete the assignment. You may also add some fields or
 * methods.
 */
public class CalcSocketClient {
	private int rcvdOKs; // --> Number of valid message contents
	private int rcvdErs; // --> Number of invalid message contents
	private int calcRes; // --> Calculation result (cf. 'RES')

	private Socket server;
	private ObjectOutputStream oosOut;
	private ObjectInputStream oisIn;

	public CalcSocketClient() {
		this.rcvdOKs = 0;
		this.rcvdErs = 0;
		this.calcRes = 0;
	}

	// Do not change this method ..
	public int getRcvdOKs() {
		return rcvdOKs;
	}

	// Do not change this method ..
	public int getRcvdErs() {
		return rcvdErs;
	}

	// Do not change this method ..
	public int getCalcRes() {
		return calcRes;
	}

	public boolean connectTo(String srvIP, int srvPort) {
		boolean status = false;
		try {
			server = new Socket(srvIP, srvPort);
			oosOut = new ObjectOutputStream(server.getOutputStream());
			oisIn = new ObjectInputStream(server.getInputStream());
			if (parseResponse(readMessage()) == Operator.RDY) {
				status = true;
			}
		} catch (UnknownHostException e) {
			err("Could not find host server:" + e.getMessage());
		} catch (IOException e) {
			err("Could not connect to server:" + e.getMessage());
		}
		return status;
	}

	public boolean disconnect() {
		boolean status = false;
		try {
			oosOut.close();
			oisIn.close();
			server.close();
			status = true;
		} catch (IOException e) {
			err("Error closing connection:" + e.getMessage());
		}
		return status;
	}

	public boolean calculate(String request) {
		// If the request is <RES>, store result into the calcRes.
		// Also: keep counting no.of <OK> and <ERR>
		sendMessage(request);
		// Wait until finished
		try {
			while(parseResponse(readMessage()) != Operator.FIN);
			info("OKs: " + rcvdOKs);
			info("Errors: " + rcvdErs);
			info("Result: " + calcRes);
		} catch (IOException e) {
			return false;
		}
		return true;
	}

	private void sendMessage(String message) {
		info("Sending: " + message);
		try {
			oosOut.writeObject(message);
		} catch (IOException e) {
			err("Error sending message:" + e.getMessage());
		}
	}

	private String readMessage() throws IOException {
		String inMessage = null;
		try {
			inMessage = (String) oisIn.readObject();
			info("Received: " + inMessage);
		} catch (ClassNotFoundException e) {
			err("Error parsing message:" + e.getMessage());
		}
		return inMessage;
	}

	private void info(String details) {
		System.out.println("[Client] " + details);
	}

	private void err(String details) {
		System.err.println("[Client] " + details);
	}

	private Operator parseResponse(String message) {
		if (message != null) {
			message.trim();
			int idxStart = message.indexOf("<");
			String msg = message.substring(idxStart + 1, message.indexOf(">", idxStart));
			int idxColumn = msg.indexOf(":");
			if (idxColumn > 0 && (msg.length() + 2) == Integer.parseInt(msg.substring(0, idxColumn))) {
				// info("Msg length is correct");
			} else {
				err("Msg length not correct: " + msg.substring(0, idxColumn));
				// TODO: send error
			}

			// Extract rest of the message
			String[] parts = msg.substring(idxColumn + 1).split("\\s+");
			for (int i = 0; i < parts.length; i++) {
				Operator op = Operator.findByName(parts[i].toUpperCase());
				if (op != null) {
					switch (op) {
					case ERR:
						rcvdErs++;
						break;
					case OK:
						rcvdOKs++;
						break;
					case RES:
						if (i + 1 < parts.length) {
							calcRes = Integer.parseInt(parts[i + 1]);
						}
						break;
					default:
						// Do nothing
						break;
					}
					if(op == Operator.OK) {
						continue;
					}
					return op;
				}
			}
		}
		return null;
	}

	private enum Operator {
		RDY, OK, ERR, FIN, RES;

		public static Operator findByName(String name) {
			for (Operator opr : values()) {
				if (opr.name().equals(name)) {
					return opr;
				}
			}
			return null;
		}
	}

}
