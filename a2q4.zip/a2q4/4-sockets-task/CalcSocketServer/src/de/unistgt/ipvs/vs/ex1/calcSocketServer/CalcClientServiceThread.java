package de.unistgt.ipvs.vs.ex1.calcSocketServer;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.rmi.RemoteException;

import de.unistgt.ipvs.vs.ex1.calculation.ICalculation;
import de.unistgt.ipvs.vs.ex1.calculationImpl.CalculationImpl;

public class CalcClientServiceThread extends Thread {

	private static int COUNT = 0;
	private Socket client = null;
	private ObjectInputStream oisIn;
	private ObjectOutputStream oosOut;

	private ICalculation calcService;
	private Operator currentOp = null;

	public CalcClientServiceThread(Socket clientSocket) {
		this.client = clientSocket;
		this.setName("Session-".concat(String.valueOf(++COUNT)));
		try {
			this.oisIn = new ObjectInputStream(client.getInputStream());
			this.oosOut = new ObjectOutputStream(client.getOutputStream());
			info("Connected.");
		} catch (IOException e) {
			err("Could not prepare client streams:" + e.getMessage());
		}
		try {
			this.calcService = new CalculationImpl();
		} catch (RemoteException e) {
			err("Error creating Calculation service " + e.getMessage());
		}
	}

	public void run() {
		if (this.oisIn == null || this.oosOut == null) {
			err("Cannot serve client. Stopping client session.");
			return;
		}

		sendMessage("RDY");
		info("Session started...");
		String message;
		while (true) {
			try {
				message = this.readMessage();
				sendMessage("OK");
				process(message);
			} catch (IOException e) {
				err("Error reading message:" + e.getMessage());
				break;
			}
		}
		info("Session terminated.");
	}

	private void sendMessage(String message) {
		//info("Sending: " + message);
		int length = message.length() + 5;
		String len = (length <= 9) ? ("0" + length) : String.valueOf(length);
		try {
			oosOut.writeObject("<" + len + ":" + message + ">");
		} catch (IOException e) {
			err("Error sending message:" + e.getMessage());
		}
	}

	private String readMessage() throws IOException {
		String inMessage = null;
		try {
			inMessage = (String) oisIn.readObject();
			info("Received: " + inMessage);
		} catch (ClassNotFoundException e) {
			err("Error parsing message:" + e.getMessage());
		}
		return inMessage;
	}

	private void info(String details) {
		System.out.println("[" + this.getName() + "] " + details);
	}

	private void err(String details) {
		System.err.println("[" + this.getName() + "] " + details);
	}

	private void process(String message) {
		if (message != null) {
			message.trim();
			int idxStart = message.indexOf("<");
			String msg = message.substring(idxStart + 1, message.indexOf(">", idxStart));
			int idxColumn = msg.indexOf(":");
			if (idxColumn > 0 && (msg.length() + 2) == Integer.parseInt(msg.substring(0, idxColumn))) {
				// info("Msg length is correct");
			} else {
				err("Msg length not correct: " + msg.substring(0, idxColumn));
				// TODO: send error
			}

			// Extract rest of the message
			String[] parts = msg.substring(idxColumn + 1).split("\\s+");
			for (String part : parts) {
				if ("".equals(part.trim())) {
					continue;
				}
				Operator op = Operator.findByName(part.toUpperCase());
				if (Operator.RES == op) {
					try {
						sendMessage("OK RES " + String.valueOf(calcService.getResult()));
					} catch (RemoteException e) {
						// Do nothing - we don't expect it to happen now
					}
				} else if (op != null) {
					currentOp = op;
					sendMessage("OK " + part);
				} else if (calculate(part)) {
					sendMessage("OK " + part);
				} else {
					sendMessage("ERR " + part);
				}
			}
			sendMessage("FIN");
		}
	}

	private boolean calculate(String token) {
		try {
			int val = Integer.parseInt(token);
			if (currentOp != null) {
				switch (currentOp) {
				case ADD:
					calcService.add(val);
					break;
				case SUB:
					calcService.subtract(val);
					break;
				case MUL:
					calcService.multiply(val);
					break;
				default: // Do nothing
					break;
				}
			}
		} catch (NumberFormatException ex) {
			// err("Invalid content: " + token);
			return false;
		} catch (RemoteException e) {
			// Do nothing - we don't expect it to happen now
		}
		return true;
	}

	private enum Operator {
		ADD, SUB, MUL, RES;

		public static Operator findByName(String name) {
			for (Operator opr : values()) {
				if (opr.name().equals(name)) {
					return opr;
				}
			}
			return null;
		}
	}
}
