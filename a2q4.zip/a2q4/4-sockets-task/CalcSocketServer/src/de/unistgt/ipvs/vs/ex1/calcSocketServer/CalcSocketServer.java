package de.unistgt.ipvs.vs.ex1.calcSocketServer;

import java.io.IOException;
import java.net.ServerSocket;

/**
 * Extend the run-method of this class as necessary to complete the assignment.
 * You may also add some fields, methods, or further classes.
 */
public class CalcSocketServer extends Thread {
	private ServerSocket srvSocket;
	private int port;

	public CalcSocketServer(int port) {
		this.srvSocket = null;
		this.port      = port;
	}
	
	@Override
	public void interrupt() {
		try {
			System.out.println("Server interrupted.");
			if (srvSocket != null) {
				srvSocket.close();
				System.out.println("Server socket closed.");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		if (port <= 0) {
			System.err.println("SocketServer listen port not specified!");
			System.exit(-1);
		}

		// Start listening server socket ..
		try {
			srvSocket = new ServerSocket(port);
		} catch (IOException e) {
			System.err.println("Error starting server: " + e.getMessage());
			System.exit(-1);
		}

		while(!srvSocket.isClosed()) {
			try {
				new CalcClientServiceThread(srvSocket.accept()).start();
			} catch (IOException e) {
				System.err.println("Could not accept client request: " + e.getMessage());
			}
		}
		System.out.println("Stopping server."); 
	}
	
	public static void main(String [] args) {
		System.out.println("Starting server on port: " + args[0]);
		CalcSocketServer server = new CalcSocketServer(Integer.valueOf(args[0]));
		server.start();
	}
}
