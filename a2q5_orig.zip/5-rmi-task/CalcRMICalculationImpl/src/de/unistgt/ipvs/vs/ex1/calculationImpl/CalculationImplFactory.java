package de.unistgt.ipvs.vs.ex1.calculationImpl;

/**
 * Change this class (implementation/signature/...) as necessary to complete the assignment.
 * You may also add some fields or methods.
 */
public class CalculationImplFactory /*...*/ {
	// TODO

}