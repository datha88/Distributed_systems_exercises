package de.unistgt.ipvs.vs.ex5.replication;

import java.net.SocketAddress;
import java.util.Collection;

public class QuorumNotReachedException extends Exception {
	private static final long serialVersionUID = 3957064339052100451L;
	
	protected final int required;
	protected final Collection<SocketAddress> achieved;
	
	public Collection<SocketAddress> getAchieved() {
		return achieved;
	}

	public QuorumNotReachedException(int required, Collection<SocketAddress> achieved) {
		super("Got " + achieved.size() + " votes, but needed " + required + " votes.");
		this.required = required;
		this.achieved = achieved;
	}
}
