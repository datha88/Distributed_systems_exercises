package de.unistgt.ipvs.vs.ex5.replication;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

import de.unistgt.ipvs.vs.ex5.communication.ReleaseReadLock;
import de.unistgt.ipvs.vs.ex5.communication.ReleaseWriteLock;
import de.unistgt.ipvs.vs.ex5.communication.RequestReadVote;
import de.unistgt.ipvs.vs.ex5.communication.RequestWriteVote;
import de.unistgt.ipvs.vs.ex5.communication.ValueResponseMessage;
import de.unistgt.ipvs.vs.ex5.communication.Vote;

public class Replica<T> extends Thread {
	public enum LockType {
		UNLOCKED, READLOCK, WRITELOCK
	};

	private int id;

	private double availability;
	private VersionedValue<T> value;
	private int noOfVotes;

	private final int MAX_BUF_LENGTH = 65507;
	protected DatagramSocket socket = null;

	protected LockType lock;

	protected boolean closeReplica;

	@SuppressWarnings("rawtypes")
	protected Map<Class, String> clientMsgTypes;

	/**
	 * This SocketAddress holds the address of the client holding the lock. This
	 * variable should be set to NULL every time the lock is set to UNLOCKED.
	 */
	protected SocketAddress lockHolder;

	@SuppressWarnings("rawtypes")
	public Replica(int id, int listenPort, double availability, int initVer,
			T initVal, int votes) {
		super("Replica:" + listenPort);

		this.id = id;
		this.noOfVotes = votes;
		this.availability = availability;
		this.value = new VersionedValue<T>(initVer, initVal);
		this.lock = LockType.UNLOCKED;
		this.closeReplica = false;

		this.clientMsgTypes = new HashMap<Class, String>();
		this.clientMsgTypes.put(RequestReadVote.class, "handleReadVoteReq");
		this.clientMsgTypes.put(RequestWriteVote.class, "handleWriteVoteReq");
		this.clientMsgTypes.put(ReadRequestMessage.class, "handleReadDataReq");
		this.clientMsgTypes.put(ReleaseReadLock.class, "handleReleaseReadLockReq");
		this.clientMsgTypes.put(ReleaseWriteLock.class, "handleReleaseWriteLockReq");
		this.clientMsgTypes
				.put(WriteRequestMessage.class, "handleWriteDataReq");
	}

	public boolean init(int listenPort) {
		SocketAddress socketAddress = new InetSocketAddress("127.0.0.1",
				listenPort);

		try {
			this.socket = new DatagramSocket(socketAddress);
		} catch (SocketException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public int getID() {
		return id;
	}

	public SocketAddress getSocketAddress() {
		return socket.getLocalSocketAddress();
	}

	/**
	 * Part a) Implement this run method to receive and process request
	 * messages. To simulate a replica that is sometimes unavailable, it should
	 * randomly discard requests as long as it is not locked. The probability
	 * for discarding a request is (1 - availability).
	 * 
	 * For each request received, it must also be checked whether the request is
	 * valid. For example: - Does the requesting client hold the correct lock? -
	 * Is the replica unlocked when a new lock is requested?
	 */
	public void run() {
		if (this.socket == null)
			return;

		while (!this.isCloseReplica()) {
			try {
				DatagramPacket request = new DatagramPacket(
						new byte[this.MAX_BUF_LENGTH], this.MAX_BUF_LENGTH);
				this.socket.receive(request);
				Object obj = this.getObjectFromMessage(request);
				this.handleClientRequest(obj, request.getSocketAddress());
			} catch (IOException e) {
				// Closing a replica on error
				this.setCloseReplica(true);
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// Someone somewhere is doing very very wrong
				this.setCloseReplica(true);
				e.printStackTrace();
			} catch (Exception e) {
				// Someone somewhere is doing very very wrong
				this.setCloseReplica(true);
				e.printStackTrace();
			}
		}

	}

	protected boolean handleClientRequest(Object obj, SocketAddress address)
			throws NoSuchMethodException, SecurityException,
			IllegalAccessException, IllegalArgumentException,
			InvocationTargetException {
		boolean ret = false;
		String handler = this.clientMsgTypes.get(obj.getClass());
		
		if (handler != null) {
			Method method = this.getClass().getMethod(handler, obj.getClass(),
					SocketAddress.class);
			ret = (boolean) method.invoke(this, obj.getClass().cast(obj),
					address);
		} else {
			System.out.println("Invalid message type");
		}

		return ret;
	}

	public boolean isCloseReplica() {
		return closeReplica;
	}

	public void setCloseReplica(boolean closeReplica) {
		this.closeReplica = closeReplica;
	}

	protected void sendVote(SocketAddress address, Vote.State state, int version)
			throws IOException, ClassNotFoundException {
		Vote vote = new Vote(state, version, this.noOfVotes);

		// get the byte array of the object
		byte[] buf = this.getByteArrFromObject(vote);
		DatagramPacket packet = new DatagramPacket(buf, buf.length, address);

		this.socket.send(packet);
	}

	protected void sendValueResponse(SocketAddress address)
			throws ClassNotFoundException, IOException {

		ValueResponseMessage<VersionedValue<T>> valResponse = new ValueResponseMessage<VersionedValue<T>>(
				this.value);
		// get the byte array of the object
		byte[] buf = this.getByteArrFromObject(valResponse);
		DatagramPacket packet = new DatagramPacket(buf, buf.length, address);
		this.socket.send(packet);
	}

	protected Object getObjectFromMessage(DatagramPacket packet)
			throws IOException, ClassNotFoundException {

		ObjectInputStream objStream = new ObjectInputStream(
				new ByteArrayInputStream(packet.getData()));
		Object obj = objStream.readObject();

		return obj;
	}

	protected byte[] getByteArrFromObject(Object obj) throws IOException,
			ClassNotFoundException {

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(baos);
		oos.writeObject(obj);
		oos.flush();

		// get the byte array of the object
		return baos.toByteArray();
	}

	public boolean handleReadVoteReq(RequestReadVote req, SocketAddress address)
			throws ClassNotFoundException, IOException {
		if(Math.random() > availability){
			//Simulating availablity 
			return false;
		}
		if (this.lock.equals(LockType.UNLOCKED)
				|| (this.lock.equals(LockType.READLOCK) && this.lockHolder
						.equals(address))) {
			this.lock = LockType.READLOCK;
			this.lockHolder = address;
			this.sendVote(address, Vote.State.YES, this.value.getVersion());
		} else {
			this.sendVote(address, Vote.State.NO, this.value.getVersion());
		}
		return true;
	}
	
	public boolean handleWriteVoteReq(RequestWriteVote req,
			SocketAddress address) throws IOException, ClassNotFoundException {
		if(Math.random() > availability){
			//Simulating availablity 
			return false;
		}
		boolean ret = true;
		if (this.lock.equals(LockType.UNLOCKED)|| (this.lock.equals(LockType.WRITELOCK) && this.lockHolder
				.equals(address))) {
			this.lock = LockType.WRITELOCK;
			this.lockHolder = address;
			this.sendVote(address, Vote.State.YES, this.value.getVersion());
		} else {
			this.sendVote(address, Vote.State.NO, this.value.getVersion());
		}
		return ret;
	}
	public boolean handleReleaseReadLockReq(ReleaseReadLock relLock, SocketAddress address) throws ClassNotFoundException, IOException{
		boolean ret = true;
		if (this.lock.equals(LockType.READLOCK)
				&& this.lockHolder.equals(address)) {
			this.lock = LockType.UNLOCKED;
			this.lockHolder = address;
			this.sendVote(address, Vote.State.YES, this.value.getVersion());
		}
		return ret;
	}
	
	public boolean handleReleaseWriteLockReq(ReleaseWriteLock relLock, SocketAddress address) throws ClassNotFoundException, IOException{
		boolean ret = true;
		if (this.lock.equals(LockType.WRITELOCK)
				&& this.lockHolder.equals(address)) {
			this.lock = LockType.UNLOCKED;
			this.lockHolder = address;
			this.sendVote(address, Vote.State.YES, this.value.getVersion());
		}
		return ret;
	}
	public boolean handleReadDataReq(ReadRequestMessage req,
			SocketAddress address) throws IOException, ClassNotFoundException {
		boolean ret = false;
		if (this.lock.equals(LockType.READLOCK)
				&& this.lockHolder.equals(address)) {
			this.sendValueResponse(address);
			ret = true;
		}
		return ret;
	}

	public boolean handleWriteDataReq(WriteRequestMessage<T> req,
			SocketAddress address) throws IOException, ClassNotFoundException {
		boolean ret = false;
		if (this.lock.equals(LockType.WRITELOCK)
				&& this.lockHolder.equals(address) && (req.getVersion()>this.value.getVersion())) {
			this.value = new VersionedValue<T>(req);
			
			this.sendVote(address, Vote.State.YES, this.value.getVersion());
			ret = true;
		}else{
			this.sendVote(address, Vote.State.NO, this.value.getVersion());
		}
		return ret;
		
	}
}
