package de.unistgt.ipvs.vs.ex5.replication;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import de.unistgt.ipvs.vs.ex5.communication.MessageWithSource;
import de.unistgt.ipvs.vs.ex5.communication.NonBlockingReceiver;
import de.unistgt.ipvs.vs.ex5.communication.ReleaseReadLock;
import de.unistgt.ipvs.vs.ex5.communication.ReleaseWriteLock;
import de.unistgt.ipvs.vs.ex5.communication.RequestReadVote;
import de.unistgt.ipvs.vs.ex5.communication.RequestWriteVote;
import de.unistgt.ipvs.vs.ex5.communication.ValueResponseMessage;
import de.unistgt.ipvs.vs.ex5.communication.Vote;

public class WeightedVoting<T> {
	protected Collection<SocketAddress> replicas;

	protected DatagramSocket socket;
	protected NonBlockingReceiver nbio;

	protected final int readQuorum;
	protected final int writeQuorum;
	
	private final int MAX_TIME_OUT = 1000;

	public WeightedVoting(Collection<SocketAddress> replicas, int totalVotes) {
		this.replicas = replicas;

		// Need not be null safe since totalVotes is primitive int not an
		// instance
		float halfOfVotes = totalVotes / 2;

		// This implies writeQuorum > totalVotes/2 => ensures write-write quorum
		writeQuorum = Double.valueOf(Math.floor(halfOfVotes + 1)).intValue();
		// This implies readQuorum+writeQuorum > totalVotes => ensures
		// write-read quorum
		readQuorum = Double.valueOf(Math.ceil(halfOfVotes)).intValue();

	}

	public boolean init(int listenport) {
		SocketAddress address = new InetSocketAddress("127.0.0.1", listenport);

		try {
			this.socket = new DatagramSocket(address);
			this.nbio = new NonBlockingReceiver(socket);
		} catch (SocketException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	/**
	 * Part c) Implement this method.
	 */
	protected Collection<MessageWithSource<Vote>> requestReadVote()
			throws QuorumNotReachedException {
		Iterator<SocketAddress> iter = this.replicas.iterator();
		Collection<MessageWithSource<Vote>> votes = new ArrayList<MessageWithSource<Vote>>();
		try {
			int sentCount = 0;

			while (iter.hasNext()) {
				this.requestToReplica(iter.next(), new RequestReadVote());

				sentCount++;
			}
			Collection<DatagramPacket> recPkts = this.nbio.receiveMessages(
					this.MAX_TIME_OUT, sentCount);
			votes = NonBlockingReceiver.unpack(recPkts);

		} catch (ClassNotFoundException | IOException e) {
			System.err.println("This is the error.." + e.getMessage());
			throw new QuorumNotReachedException(this.readQuorum, this.replicas);

		}

		return votes;
	}

	protected void requestToReplica(SocketAddress address, Object requestObj)
			throws ClassNotFoundException, IOException {
		byte[] buf = this.getByteArrFromObject(requestObj);
		DatagramPacket packet = new DatagramPacket(buf, buf.length, address);
		this.socket.send(packet);
	}

	/**
	 * Part c) Implement this method.
	 */
	protected void releaseReadLock(Collection<SocketAddress> lockedReplicas) {
		Iterator<SocketAddress> iter = this.replicas.iterator();
		try {
			int sentCount = 0;
			while (iter.hasNext()) {

				this.requestToReplica(iter.next(), new ReleaseReadLock());
				sentCount++;
			}
			Collection<DatagramPacket> recPkts = this.nbio.receiveMessages(
					this.MAX_TIME_OUT, sentCount);
			NonBlockingReceiver.unpack(recPkts);
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Part d) Implement this method.
	 */
	protected Collection<MessageWithSource<Vote>> requestWriteVote()
			throws QuorumNotReachedException {
		Iterator<SocketAddress> iter = this.replicas.iterator();
		Collection<MessageWithSource<Vote>> votes = new ArrayList<MessageWithSource<Vote>>();
		try {
			int sentCount = 0;

			while (iter.hasNext()) {
				this.requestToReplica(iter.next(), new RequestWriteVote());

				sentCount++;
			}
			Collection<DatagramPacket> recPkts = this.nbio.receiveMessages(
					this.MAX_TIME_OUT, sentCount);
			votes = NonBlockingReceiver.unpack(recPkts);

		} catch (ClassNotFoundException | IOException e) {
			System.err.println("This is the error.." + e.getMessage());
			throw new QuorumNotReachedException(this.writeQuorum, this.replicas);

		}
		return votes;
	}

	/**
	 * Part d) Implement this method.
	 */
	protected void releaseWriteLock(Collection<SocketAddress> lockedReplicas) {
		Iterator<SocketAddress> iter = this.replicas.iterator();
		try {
			int sentCount = 0;
			while (iter.hasNext()) {

				this.requestToReplica(iter.next(), new ReleaseWriteLock());
				sentCount++;
			}
			Collection<DatagramPacket> recPkts = this.nbio.receiveMessages(
					this.MAX_TIME_OUT, sentCount);
			NonBlockingReceiver.unpack(recPkts);
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Part c) Implement this method.
	 */
	protected T readReplica(SocketAddress replica) {
		try {
			this.requestToReplica(replica, new ReadRequestMessage());
			Vector<DatagramPacket> pktCollection = this.nbio.receiveMessages(
					this.MAX_TIME_OUT, 1);
			Collection<MessageWithSource<ValueResponseMessage<T>>> resp = NonBlockingReceiver
					.unpack(pktCollection);

			return resp.iterator().next().getMessage().getValue();
		} catch (ClassNotFoundException | IOException e) {

			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Part d) Implement this method.
	 */
	protected void writeReplicas(Collection<SocketAddress> lockedReplicas,
			VersionedValue<T> newValue) {
		Iterator<SocketAddress> iter = lockedReplicas.iterator();
		try {
			int msgCount = 0;
			
			while (iter.hasNext()) {
				SocketAddress address = iter.next();
				this.requestToReplica(address, new WriteRequestMessage<T>(
						newValue));
				msgCount++;
			}
			Vector<DatagramPacket> pktCollection = this.nbio.receiveMessages(
					this.MAX_TIME_OUT, msgCount);
			// This can be used in case of failures between locking and voting
			@SuppressWarnings("unused")
			Collection<MessageWithSource<Vote>> votes = NonBlockingReceiver
					.unpack(pktCollection);
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Part c) Implement this method (and checkReadQuorum()/checkWriteQuorum,
	 * see below) to read the replicated value using the weighted voting
	 * protocol.
	 */
	public VersionedValue<T> get() throws QuorumNotReachedException {
		Collection<MessageWithSource<Vote>> votes = this.requestReadVote();
		Collection<MessageWithSource<Vote>> positiveVotes = this
				.checkReadQuorum(votes);
		VersionedValue<T> result = this.readReplicas(positiveVotes);
		Collection<SocketAddress> releaseAddr = this
				.getAddressFromMessageWithSrc(positiveVotes);
		this.releaseReadLock(releaseAddr);
		return result;
	}

	private Collection<SocketAddress> getAddressFromMessageWithSrc(
			Collection<MessageWithSource<Vote>> votes) {
		Iterator<MessageWithSource<Vote>> iter = votes.iterator();
		Collection<SocketAddress> addrList = new ArrayList<SocketAddress>();
		while (iter.hasNext()) {
			addrList.add(iter.next().getSource());
		}
		return addrList;
	}

	protected VersionedValue<T> readReplicas(
			Collection<MessageWithSource<Vote>> positiveVotes) {
		Iterator<MessageWithSource<Vote>> iter = positiveVotes.iterator();
		VersionedValue<T> ret = null;
		while (iter.hasNext()) {
			MessageWithSource<Vote> msg = iter.next();

			@SuppressWarnings("unchecked")
			VersionedValue<T> data = (VersionedValue<T>) this.readReplica(msg
					.getSource());

			if (ret == null || ret.getVersion() < data.getVersion()) {
				ret = data;
			}

		}
		return ret;
	}

	/**
	 * Part d) Implement this method to set the replicated value using the
	 * weighted voting protocol.
	 */
	public void set(T value) throws QuorumNotReachedException {
		VersionedValue<T> verVal = this.get();
		VersionedValue<T> newVal = new VersionedValue<T>(
				verVal.getVersion() + 1, value);
		Collection<MessageWithSource<Vote>> votes = this.requestWriteVote();
		Collection<SocketAddress> lockedReplicas = this
				.getAddressFromMessageWithSrc(this.checkWriteQuorum(votes));
		
		this.writeReplicas(lockedReplicas, newVal);

		this.releaseWriteLock(lockedReplicas);
	}

	/**
	 * Part c) Implement these methods to check whether a sufficient number of
	 * replies were received. If a sufficient number was received, this method
	 * should return the {@link SocketAddress}s of the locked {@link Replica}s.
	 * Otherwise, a QuorumNotReachedException must be thrown.
	 * 
	 * @throws QuorumNotReachedException
	 */
	protected Collection<MessageWithSource<Vote>> checkReadQuorum(
			Collection<MessageWithSource<Vote>> replies)
			throws QuorumNotReachedException {
		int voteCount = 0;
		Iterator<MessageWithSource<Vote>> iter = replies.iterator();
		Collection<MessageWithSource<Vote>> postiveVotes = new ArrayList<MessageWithSource<Vote>>();
		while (iter.hasNext()) {
			MessageWithSource<Vote> voteWitSrc = iter.next();
			
			if (voteWitSrc.getMessage().getState().equals(Vote.State.YES)) {
				postiveVotes.add(voteWitSrc);
				voteCount = voteCount + voteWitSrc.getMessage().getNoOfVotes();
			}

		}

		if (voteCount >= this.readQuorum) {
			return postiveVotes;
		}
		throw new QuorumNotReachedException(voteCount, this.replicas);
	}

	protected Collection<MessageWithSource<Vote>> checkWriteQuorum(
			Collection<MessageWithSource<Vote>> replies)
			throws QuorumNotReachedException {
		int voteCount = 0;
		Iterator<MessageWithSource<Vote>> iter = replies.iterator();
		Collection<MessageWithSource<Vote>> postiveVotes = new ArrayList<MessageWithSource<Vote>>();
		while (iter.hasNext()) {
			MessageWithSource<Vote> voteWitSrc = iter.next();
			if (voteWitSrc.getMessage().getState().equals(Vote.State.YES)) {
				postiveVotes.add(voteWitSrc);
				voteCount = voteCount + voteWitSrc.getMessage().getNoOfVotes();
			}

		}
		
		
		if (voteCount >= this.writeQuorum) {
			return postiveVotes;
		}
		
		throw new QuorumNotReachedException(voteCount, this.replicas);
	}

	/**
	 * Get bytes array from object for sending data to replicas
	 * 
	 * @param obj
	 * @return
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	protected byte[] getByteArrFromObject(Object obj) throws IOException,
			ClassNotFoundException {

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(baos);
		oos.writeObject(obj);
		oos.flush();

		// get the byte array of the object
		return baos.toByteArray();
	}

}
