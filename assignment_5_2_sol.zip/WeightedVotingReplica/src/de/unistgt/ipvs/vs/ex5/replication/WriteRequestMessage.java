package de.unistgt.ipvs.vs.ex5.replication;

public class WriteRequestMessage<T> extends VersionedValue<T> {
	private static final long serialVersionUID = -3310552644845307035L;

	public WriteRequestMessage(VersionedValue<T> versionedValue) {
		super(versionedValue);
	}
	
	public WriteRequestMessage(int version, T value) {
		super(version, value);
	}
}
