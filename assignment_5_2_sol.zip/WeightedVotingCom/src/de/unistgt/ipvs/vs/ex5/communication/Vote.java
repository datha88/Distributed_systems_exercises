package de.unistgt.ipvs.vs.ex5.communication;

import java.io.Serializable;

public class Vote implements Serializable {
	private static final long serialVersionUID = -7977513854513072668L;

	public enum State { YES, NO };
	
	protected final State responseState;
	protected final int version;
	protected final int noOfVotes;
	
	public State getState() {
		return responseState;
	}
	
	public int getVersion() {
		return version;
	}
	
	public int getNoOfVotes() {
		return noOfVotes;
	}
	
	public Vote(State responseState, int version, int noOfVotes) {
		this.responseState = responseState;
		this.version = version;
		this.noOfVotes = noOfVotes;
	}
}
