package de.unistgt.ipvs.vs.ex5.communication;

import java.io.Serializable;

public class ReleaseReadLock implements Serializable {
	private static final long serialVersionUID = -2889680559006519738L;
}
