package de.unistgt.ipvs.vs.ex5.communication;

import java.io.Serializable;

public class ReleaseWriteLock implements Serializable {
	private static final long serialVersionUID = 3315386831872060741L;
}
