package de.unistgt.ipvs.vs.ex5.replication;

import java.net.SocketAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.List;

// !!! DO NOT EDIT !!!
public class TestMain {
	private static int      REPLICA_PORT = 4000;
	private static int      REPLICA_CNT  =   10;

	private static double[] REPLICA_PROB = new double[] {0.9, 0.7, 0.8};
	private static int[]    REPLICA_VERS = new int[]    {1  , 0  , 1  };
	private static double[] REPLICA_VALS = new double[] {5.0, 2.0, 5.0};

	/**
	 * @param args
	 * @throws SocketException
	 */
	public static void main(String[] args) throws SocketException {
		List<Replica<Double>> replicas     = new ArrayList<Replica<Double>>(REPLICA_CNT);
		List<SocketAddress>   replicaAddrs = new ArrayList<SocketAddress>(replicas.size());

		for (int i=0; i<REPLICA_CNT; i++) {
			int    port  = REPLICA_PORT + i;
			int    vers  = REPLICA_VERS[i % REPLICA_VALS.length];
			double value = REPLICA_VALS[i % REPLICA_VALS.length];
			double prob  = REPLICA_PROB[i % REPLICA_VALS.length];
			
			Replica<Double> r = new Replica<Double>(i, port, prob, vers, value, 1);
			r.init(port);
			
			replicas.add(r);
			replicaAddrs.add(r.getSocketAddress());
			
			r.start();
		}

		try {
			WeightedVoting<Double> wv = new WeightedVoting<Double>(replicaAddrs, 10);
			if (!wv.init(4999)) throw new Exception("Cannot initialize 'WeightedVoting'!");
			
			double y = wv.get().getValue();
			System.out.println("Weighted Voting: y is " + y);

			wv.set(9.9);
			y = wv.get().getValue();

			System.out.println("Weighted Voting: y is " + y);
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Exception occured: " + e.getMessage());
			System.exit(-1);
		}
		
		System.exit(0);
	}

}
